<!--
Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.

SPDX-License-Identifier: curl
-->

# curl dependencies

Supported minimum versions of libs and build tools.

## Portability

We write curl and libcurl to compile with C89 compilers on 32-bit and up
machines. Most of libcurl assumes more or less POSIX compliance but that is
not a requirement. The compiler must support a 64-bit integer type as well as
supply a stdint.h header file that defines C99-style fixed-width integer types
like uint32_t.

We write libcurl to build and work with lots of third party tools, and we
want it to remain functional and buildable with these and later versions
(older versions may still work but is not what we work hard to maintain):

## Dependencies

We aim to support these or later versions:

- brotli        1.0.0 (2017-09-21)
- c-ares        1.16.0 (2020-03-13)
- GnuTLS        3.6.5 (2018-12-01)
- libidn2       2.0.0 (2017-03-29)
- libgsasl      1.6.0 (2010-12-14)
- libpsl        0.16.0 (2016-12-10)
- LibreSSL      2.9.1 (2019-04-21)
- libssh        0.9.0 (2019-06-28)
- libssh2       1.9.0 (2019-06-20)
- mbedTLS       3.2.0 (2022-07-11)
- MIT Kerberos  1.3 (2003-07-31)
- nettle        3.4.1 (2018-12-04)
- nghttp2       1.15.0 (2016-09-25)
- nghttp3       1.0.0 (2023-10-15)
- ngtcp2        1.0.0 (2023-10-15), with OpenSSL 3.5.0+: 1.12.0 (2025-04-16)
- OpenLDAP      2.0 (2000-08-01)
- OpenSSL       3.0.0 (2021-09-07)
- quiche        0.20.0 (2023-12-12)
- Windows       Vista 6.0 (2006-11-08 - 2012-04-10)
- wolfSSL       5.0.0 (2021-11-01)
- zlib          1.2.5.2 (2011-12-11)
- zstd          1.0 (2016-08-31)

## Build tools

When writing code (mostly for generating stuff included in release tarballs)
we use a few "build tools" and we make sure that we remain functional with
these or later versions:

- clang-tidy     17.0.0 (2023-09-19), recommended: 19.1.0 (2024-09-17)
- cmake          3.18 (2020-07-15)
- GNU autoconf   2.59 (2003-11-06)
- GNU automake   1.7 (2002-09-25)
- GNU libtool    1.4.2 (2001-09-11)
- GNU m4         1.4 (2007-09-21)
- mingw-w64      3.0 (2013-09-20)
- perl           5.8 (2002-07-19), on Windows: 5.22 (2015-06-01)
- Visual Studio  2010 10.0 (2010-04-12 - 2020-07-14)

## Testing

Certain tests require the following packages to operate. In some cases, tests
that do not find the necessary requirements are automatically skipped.

- OpenSSL        (see above)
- nghttp2        (see above)
- OpenSSH
- perl           (see above)
- pytest
- Python         3.8 (2019-10-14)
- stunnel
